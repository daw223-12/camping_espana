INSERT INTO `places` (`id`, `name`, `description`, `type`, `created_at`, `updated_at`) VALUES (NULL, 'Plaza mayor', 'Es la plaza mayor', 'Plaza', NULL, NULL);

INSERT INTO `places` (`id`, `name`, `description`, `type`, `created_at`, `updated_at`) VALUES (NULL, 'Contiendas', 'Son una lomas', 'lomas', NULL, NULL);

INSERT INTO `places` (`id`, `name`, `description`, `type`, `created_at`, `updated_at`) VALUES (NULL, 'Moreras', 'Es una playa cuya agua no es salada', 'Playa', NULL, NULL);